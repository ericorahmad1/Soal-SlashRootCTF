require "base64"

def encode_file(c,v)
	besar = Array('A'..'Z').reverse
	angka = Array('0'..'9')
	symbol = "`~!@#$%^&*()_'-=+[]{}\|:;<>,.?/ "
	a = Array('a'..'z').concat(besar).concat(angka).concat(symbol.split(//))
	chiper = Array('1'..'93').reverse
	hash = Hash[a.zip(chiper)]
	res = ""
	puts
	puts
	for i in c.split(//)
		b = hash[i]
		res += b.to_s << ","
	end

	output = File.open(v, "w")
	output << Base64.urlsafe_encode64(res.reverse!)	
	output.close

	puts "Encode finish"
	return res
end

puts "What do you want from me ? "
puts "ONLY TEXT FILE"
puts "1. Encode My File"
print "Your answer : "
answer = gets.chomp!.to_i
	
	case answer
	when 1
		print "Input File to encode : "
		f = gets.chomp!
		file = File.open(f, "r")
		print "Save to file : "
		s = gets.chomp!
		encode_file(file.read, s)
	end










